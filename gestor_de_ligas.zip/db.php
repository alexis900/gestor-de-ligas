<?php
$con = mysqli_connect("localhost", "ligas", "123456", "ligas");
?>